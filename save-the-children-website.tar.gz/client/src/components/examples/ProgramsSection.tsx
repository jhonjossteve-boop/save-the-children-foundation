import ProgramsSection from '../ProgramsSection';

export default function ProgramsSectionExample() {
  return <ProgramsSection />;
}
