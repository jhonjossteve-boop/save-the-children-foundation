import HowItHelps from '../HowItHelps';

export default function HowItHelpsExample() {
  return <HowItHelps />;
}
