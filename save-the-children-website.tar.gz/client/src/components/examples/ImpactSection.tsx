import ImpactSection from '../ImpactSection';

export default function ImpactSectionExample() {
  return <ImpactSection />;
}
